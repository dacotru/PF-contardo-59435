export interface Curso {
  id: string;
  nombre: string;
  modalidad: string;
  profesor: string;
  createdAt?: string; 
}
